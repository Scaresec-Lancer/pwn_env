.. autoprogram:: pwndbg.commands.aslr:parser
   :prog: aslr
