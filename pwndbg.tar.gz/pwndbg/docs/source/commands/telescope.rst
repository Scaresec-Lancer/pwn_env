.. autoprogram:: pwndbg.commands.telescope:parser
   :prog: telescope
