:mod:`pwndbg.config` --- pwndbg.config
=============================================

.. automodule:: pwndbg.config
    :members:
