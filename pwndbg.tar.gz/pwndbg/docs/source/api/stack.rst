:mod:`pwndbg.stack` --- pwndbg.stack
=============================================

.. automodule:: pwndbg.stack
    :members:
