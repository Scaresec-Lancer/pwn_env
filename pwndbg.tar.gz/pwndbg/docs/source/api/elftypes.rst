:mod:`pwndbg.elftypes` --- pwndbg.elftypes
=============================================

.. automodule:: pwndbg.elftypes
    :members:
