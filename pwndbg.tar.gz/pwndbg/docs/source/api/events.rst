:mod:`pwndbg.events` --- pwndbg.events
=============================================

.. automodule:: pwndbg.events
    :members:
