:mod:`pwndbg.auxv` --- pwndbg.auxv
=============================================

.. automodule:: pwndbg.auxv
    :members:
