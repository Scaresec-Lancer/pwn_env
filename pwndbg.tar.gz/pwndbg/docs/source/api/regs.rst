:mod:`pwndbg.regs` --- pwndbg.regs
=============================================

.. automodule:: pwndbg.regs
    :members:
