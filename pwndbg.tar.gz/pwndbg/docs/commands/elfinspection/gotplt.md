## Command: gotplt ##
```
usage: gotplt [-h]
```
Prints any symbols found in the .got.plt section if it exists.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


