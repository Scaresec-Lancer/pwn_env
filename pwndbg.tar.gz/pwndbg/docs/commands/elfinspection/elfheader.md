## Command: elfheader ##
```
usage: elfheader [-h]
```
Prints the section mappings contained in the ELF header.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


