## Command: plt ##
```
usage: plt [-h]
```
Prints any symbols found in the .plt section if it exists.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


