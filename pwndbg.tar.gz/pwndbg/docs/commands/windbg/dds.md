## Command: dds ##
```
usage: dds [-h] addr
```
Dump pointers and symbols at the specified address.  

| Positional Argument | Info |
|---------------------|------|
| addr | The address to dump from. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


