## Command: bp ##
```
usage: bp [-h] where
```
Set a breakpoint at the specified address.  

| Positional Argument | Info |
|---------------------|------|
| where | The address to break at. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


