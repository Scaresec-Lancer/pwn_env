## Command: eza ##
```
usage: eza [-h] address data
```
Write a string at the specified address.  

| Positional Argument | Info |
|---------------------|------|
| address | The address to write to. |
| data | The string to write. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


