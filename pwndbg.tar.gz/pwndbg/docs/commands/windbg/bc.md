## Command: bc ##
```
usage: bc [-h] [which]
```
Clear the breakpoint with the specified index.  

| Positional Argument | Info |
|---------------------|------|
| which | Index of the breakpoint to clear. (default: *) |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


