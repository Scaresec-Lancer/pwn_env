## Command: eq ##
```
usage: eq [-h] address [data [data ...]]
```
Write hex qwords at the specified address.  

| Positional Argument | Info |
|---------------------|------|
| address | The address to write to. |
| data | The qwords to write. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


