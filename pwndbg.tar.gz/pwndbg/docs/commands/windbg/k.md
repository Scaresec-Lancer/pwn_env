## Command: k ##
```
usage: k [-h]
```
Print a backtrace (alias 'bt').  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


