## Command: bl ##
```
usage: bl [-h]
```
List breakpoints.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


