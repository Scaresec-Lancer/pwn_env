## Command: be ##
```
usage: be [-h] [which]
```
Enable the breakpoint with the specified index.  

| Positional Argument | Info |
|---------------------|------|
| which | Index of the breakpoint to enable. (default: *) |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


