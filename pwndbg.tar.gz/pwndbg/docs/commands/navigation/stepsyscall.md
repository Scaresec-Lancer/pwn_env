## Command: stepsyscall ##
```
usage: stepsyscall [-h]
```
Breaks at the next syscall by taking branches.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


