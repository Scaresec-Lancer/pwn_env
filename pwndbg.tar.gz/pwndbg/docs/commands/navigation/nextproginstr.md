## Command: nextproginstr ##
```
usage: nextproginstr [-h]
```
Breaks at the next instruction that belongs to the running program  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


