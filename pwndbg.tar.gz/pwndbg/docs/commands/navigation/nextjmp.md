## Command: nextjmp ##
```
usage: nextjmp [-h]
```
Breaks at the next jump instruction.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


