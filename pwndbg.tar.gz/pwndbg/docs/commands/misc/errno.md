## Command: errno ##
```
usage: errno [-h] [err]
```
Converts errno (or argument) to its string representation.  

| Positional Argument | Info |
|---------------------|------|
| err | Errno; if not passed, it is retrieved from __errno_location |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


