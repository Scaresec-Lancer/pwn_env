## Command: entry_point ##
```
usage: entry_point [-h]
```
GDBINIT compatibility alias to print the entry point. See also the 'entry' command.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


