## Command: save_ida ##
```
usage: save_ida [-h]
```
Save the ida database.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


