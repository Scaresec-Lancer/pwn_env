## Command: memfrob ##
```
usage: memfrob [-h] address count
```
Memfrobs a region of memory.  

| Positional Argument | Info |
|---------------------|------|
| address | The address to start xoring at. |
| count | The number of bytes to xor. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


