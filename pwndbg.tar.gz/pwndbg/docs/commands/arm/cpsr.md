## Command: cpsr ##
```
usage: cpsr [-h]
```
Print out ARM CPSR register  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


