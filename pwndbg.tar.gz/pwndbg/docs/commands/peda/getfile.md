## Command: getfile ##
```
usage: getfile [-h]
```
Gets the current file.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


