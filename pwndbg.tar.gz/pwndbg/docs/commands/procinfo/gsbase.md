## Command: gsbase ##
```
usage: gsbase [-h]
```
Prints out the GS base address. See also $gsbase.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


