## Command: dumpargs ##
```
usage: dumpargs [-h] [-f]
```
Prints determined arguments for call instruction.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |
| --force | Force displaying of all arguments. (default: False) |


