## Command: canary ##
```
usage: canary [-h]
```
Print out the current stack canary.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


