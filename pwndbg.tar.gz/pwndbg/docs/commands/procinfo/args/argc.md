## Command: argc ##
```
usage: argc [-h]
```
Prints out the number of arguments.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


