## Command: reload ##
```
usage: reload [-h]
```
Reload pwndbg.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


