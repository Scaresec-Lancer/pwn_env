## Command: arenas ##
```
usage: arenas [-h]
```
Prints out allocated arenas.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |


