import pwndbg.commands.context


def warmup():
    pwndbg.commands.context.context()


def run():
    pwndbg.commands.context.context()
