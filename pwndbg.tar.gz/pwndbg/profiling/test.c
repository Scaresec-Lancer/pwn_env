#include <stdio.h>

int main() {
  puts("lets go");
  while(1);
}
